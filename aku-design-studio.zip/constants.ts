import { 
  Palette, 
  Monitor, 
  PenTool, 
  Search, 
  CheckCircle 
} from "lucide-react";

// Navigation Links
export const NAV_LINKS = [
  { name: 'Home', href: '#home' },
  { name: 'About', href: '#about' },
  { name: 'Portfolio', href: '#portfolio' },
  { name: 'Process', href: '#process' },
  { name: 'Clients', href: '#clients' },
  { name: 'Testimonials', href: '#testimonials' },
  { name: 'Contact', href: '#contact' },
];

// Hero Content
export const HERO_CONTENT = {
  headline: "Turning your ideas into captivating visual experiences",
  subtext: "UI/UX Design, Brand Identity, and Graphics with a modern, creative approach.",
  ctaPrimary: "View Work",
  ctaSecondary: "Get Started",
};

// About Content
export const ABOUT_CONTENT = {
  title: "About Us",
  description: "Aku Design Studio bridges the gap between dreams and reality with cutting-edge knowledge and endless creativity. We are a team of designers and developers passionate about creating lasting digital experiences. Our goal is not just beautiful design, but creating solutions that set your business apart.",
  skills: [
    "UI/UX Design",
    "Brand Identity",
    "Graphic Design",
    "Packaging Design"
  ],
  tools: ["Figma", "Adobe Photoshop", "Adobe Illustrator", "React", "After Effects"]
};

// Portfolio Data
export interface Project {
  id: number;
  title: string;
  client: string;
  category: string;
  image: string;
  gallery?: string[];
  description: string;
  fullDescription: string;
  tags: string[];
}

export const PROJECTS: Project[] = [
  {
    id: 1,
    title: "Noava\nFintech Platform",
    client: "Noava Financial",
    category: "Product Design",
    image: "https://images.unsplash.com/photo-1551288049-bebda4e38f71?q=80&w=1600&auto=format&fit=crop",
    gallery: [
        "https://images.unsplash.com/photo-1551288049-bebda4e38f71?q=80&w=1600&auto=format&fit=crop",
        "https://images.unsplash.com/photo-1563986768609-322da13575f3?q=80&w=1600&auto=format&fit=crop",
        "https://images.unsplash.com/photo-1556761175-5973dc0f32e7?q=80&w=1600&auto=format&fit=crop"
    ],
    description: "Complete redesign of a financial management dashboard.",
    fullDescription: "This project involved extensive user research and a complete UX redesign of the Noava financial platform. The main goal was to simplify complex financial processes for everyday users.",
    tags: ["UI/UX", "Fintech", "Dashboard"]
  },
  {
    id: 2,
    title: "Lumina\nCafe Branding",
    client: "Lumina Coffee Co.",
    category: "Branding",
    image: "https://images.unsplash.com/photo-1497935586351-b67a49e012bf?q=80&w=1600&auto=format&fit=crop",
    gallery: [
        "https://images.unsplash.com/photo-1497935586351-b67a49e012bf?q=80&w=1600&auto=format&fit=crop",
        "https://images.unsplash.com/photo-1511920170033-f8396924c348?q=80&w=1600&auto=format&fit=crop",
        "https://images.unsplash.com/photo-1509042239860-f550ce710b93?q=80&w=1600&auto=format&fit=crop"
    ],
    description: "Creating a modern and minimal identity.",
    fullDescription: "For Lumina, we sought a blend of warmth and modernity. The color palette and custom typography were designed to convey a sense of calm and luxury.",
    tags: ["Branding", "Logo Design", "Print"]
  },
  {
    id: 3,
    title: "Safar\nTravel App",
    client: "Safar Global",
    category: "Mobile",
    image: "https://images.unsplash.com/photo-1469854523086-cc02fe5d8800?q=80&w=1600&auto=format&fit=crop",
    gallery: [
         "https://images.unsplash.com/photo-1469854523086-cc02fe5d8800?q=80&w=1600&auto=format&fit=crop",
         "https://images.unsplash.com/photo-1476514525535-07fb3b4ae5f1?q=80&w=1600&auto=format&fit=crop",
         "https://images.unsplash.com/photo-1503220317375-aaad6143d41b?q=80&w=1600&auto=format&fit=crop"
    ],
    description: "UI design for a booking application.",
    fullDescription: "The main challenge was displaying a large volume of information (hotels, flights) on small mobile screens without creating visual clutter.",
    tags: ["App Design", "iOS", "Android"]
  },
  {
    id: 4,
    title: "Techno\nCorporate Site",
    client: "Techno Industries",
    category: "Web Design",
    image: "https://images.unsplash.com/photo-1497366216548-37526070297c?q=80&w=1600&auto=format&fit=crop",
    gallery: [
         "https://images.unsplash.com/photo-1497366216548-37526070297c?q=80&w=1600&auto=format&fit=crop",
         "https://images.unsplash.com/photo-1486406141726-eda3203fe5a9?q=80&w=1600&auto=format&fit=crop"
    ],
    description: "Developing a modern website with engaging animations.",
    fullDescription: "A single-page landing page to introduce Techno's new technology products with a focus on user interaction.",
    tags: ["Web Design", "Frontend", "Animation"]
  },
  {
    id: 5,
    title: "Summer\nCampaign",
    client: "Fashion Week",
    category: "Graphics",
    image: "https://images.unsplash.com/photo-1507525428034-b723cf961d3e?q=80&w=1600&auto=format&fit=crop",
    gallery: [
        "https://images.unsplash.com/photo-1507525428034-b723cf961d3e?q=80&w=1600&auto=format&fit=crop",
        "https://images.unsplash.com/photo-1483985988355-763728e1935b?q=80&w=1600&auto=format&fit=crop"
    ],
    description: "Social media post designs.",
    fullDescription: "A series of banners and Instagram stories to promote a special summer sale using vibrant, energetic colors.",
    tags: ["Social Media", "Graphic Design"]
  },
  {
    id: 6,
    title: "Organic\nPackaging",
    client: "Pure Roots",
    category: "Packaging",
    image: "https://images.unsplash.com/photo-1605647540924-852290f6b0d5?q=80&w=1600&auto=format&fit=crop",
    gallery: [
         "https://images.unsplash.com/photo-1605647540924-852290f6b0d5?q=80&w=1600&auto=format&fit=crop",
         "https://images.unsplash.com/photo-1542838132-92c53300491e?q=80&w=1600&auto=format&fit=crop"
    ],
    description: "Eco-friendly packaging design.",
    fullDescription: "Using recyclable materials and minimal design to showcase the purity of organic products.",
    tags: ["Packaging", "Eco-friendly"]
  }
];

// Process Steps
export const PROCESS_STEPS = [
  {
    id: 1,
    title: "Discovery",
    desc: "Consultation to understand your goals.",
    icon: Monitor
  },
  {
    id: 2,
    title: "Research",
    desc: "Competitor analysis and moodboarding.",
    icon: Search
  },
  {
    id: 3,
    title: "Design",
    desc: "Execution and refinement based on feedback.",
    icon: Palette
  },
  {
    id: 4,
    title: "Delivery",
    desc: "Final assets handover and support.",
    icon: CheckCircle
  }
];

// Testimonials (Limited to 5)
export const TESTIMONIALS = [
  {
    id: 1,
    name: "Ali Rezaei",
    role: "CEO at Techno",
    text: "Working with Aku was fantastic. They delivered exactly what we had in mind, with quality exceeding our expectations."
  },
  {
    id: 2,
    name: "Sara Ahmadi",
    role: "Marketing Director",
    text: "The branding they created for our cafe completely transformed our business image. Highly recommended!"
  },
  {
    id: 3,
    name: "James Wilson",
    role: "Product Lead",
    text: "From concept to final delivery, the process was smooth and the results were world-class. A truly creative partner."
  },
  {
    id: 4,
    name: "Emily Carter",
    role: "Founder at Bloom",
    text: "The attention to detail in the UI design was impeccable. Our user engagement increased by 40% after the launch."
  },
  {
    id: 5,
    name: "Mohammad Karimi",
    role: "CTO at NextGen",
    text: "Professional, timely, and incredibly creative. Aku Design Studio is now our go-to agency for all digital products."
  }
];

// Client Logos
export const CLIENTS = [
    { name: "Google", logo: "G" },
    { name: "Spotify", logo: "S" },
    { name: "Airbnb", logo: "A" },
    { name: "Nike", logo: "N" },
    { name: "Apple", logo: "A" },
    { name: "Uber", logo: "U" },
    { name: "Netflix", logo: "N" },
    { name: "Tesla", logo: "T" },
];