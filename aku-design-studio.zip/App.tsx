import React, { memo } from 'react';
import { motion } from 'framer-motion';
import Navbar from './components/Navbar';
import Hero from './components/Hero';
import About from './components/About';
import Portfolio from './components/Portfolio';
import Process from './components/Process';
import Clients from './components/Clients';
import Testimonials from './components/Testimonials';
import Contact from './components/Contact';

// Optimized Background Component
// wrapped in memo to prevent re-renders on parent state changes
const Background = memo(() => (
  <div className="fixed inset-0 z-0 overflow-hidden pointer-events-none bg-gray-50 dark:bg-black transition-colors duration-500">
    
    {/* Global Subtle Blue Mist Gradient - Reduced animation complexity for performance */}
    <motion.div 
        animate={{ 
            opacity: [0.3, 0.5, 0.3],
        }}
        transition={{ duration: 10, repeat: Infinity, repeatType: 'reverse' }}
        className="absolute inset-0 opacity-40 dark:opacity-20 bg-[radial-gradient(circle_at_50%_50%,_rgba(28,207,217,0.15),_transparent_70%)] will-change-opacity"
    />

    {/* Moving Orbs - Simplified coordinates for smoother, lighter rendering */}
    <motion.div 
      animate={{ 
        transform: ['translate(0px, 0px)', 'translate(50px, -50px)', 'translate(0px, 0px)'],
      }}
      transition={{ duration: 15, repeat: Infinity, ease: "linear" }}
      className="absolute top-[-10%] left-[-10%] w-[40vw] h-[40vw] bg-aku-teal/10 dark:bg-aku-teal/5 rounded-full blur-[100px] mix-blend-multiply dark:mix-blend-normal will-change-transform"
    />
    
    <motion.div 
      animate={{ 
        transform: ['translate(0px, 0px)', 'translate(-50px, 50px)', 'translate(0px, 0px)'],
      }}
      transition={{ duration: 20, repeat: Infinity, ease: "linear" }}
      className="absolute bottom-[-10%] right-[-10%] w-[50vw] h-[50vw] bg-blue-200/20 dark:bg-blue-900/10 rounded-full blur-[120px] mix-blend-multiply dark:mix-blend-normal will-change-transform"
    />

     <motion.div 
      animate={{ 
        opacity: [0.1, 0.2, 0.1],
      }}
      transition={{ duration: 8, repeat: Infinity, ease: "easeInOut" }}
      className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[600px] h-[600px] bg-purple-200/20 dark:bg-purple-900/5 rounded-full blur-[100px] mix-blend-multiply dark:mix-blend-normal will-change-opacity"
    />
    
    {/* Static Noise Overlay - Lightweight texture */}
    <div className="absolute inset-0 bg-[url('https://grainy-gradients.vercel.app/noise.svg')] opacity-[0.02] dark:opacity-[0.03] mix-blend-overlay"></div>
  </div>
));

function App() {
  return (
    <div className="min-h-screen w-full flex flex-col overflow-x-hidden relative selection:bg-aku-teal selection:text-black">
      <Background />
      <Navbar />
      <main className="flex-grow relative z-10">
        <Hero />
        <About />
        <Portfolio />
        <Process />
        <Clients />
        <Testimonials />
      </main>
      <Contact />
    </div>
  );
}

export default App;