
import React from 'react';
import { motion } from 'framer-motion';
import { Instagram, Linkedin, Dribbble, Mail, ArrowRight } from 'lucide-react';

const Contact: React.FC = () => {
  return (
    <footer id="contact" className="relative pt-24 pb-12 overflow-hidden">
      <div className="container mx-auto px-6 relative z-10">
        
        <div className="max-w-5xl mx-auto bg-gray-100 dark:bg-[#111] rounded-[3rem] p-8 md:p-12 border border-gray-200 dark:border-white/10 flex flex-col mb-16 transition-colors duration-500 shadow-2xl">
            
            <div className="flex flex-col lg:flex-row gap-12">
                
                {/* Left: Header & Info */}
                {/* Removed order classes: In HTML flow, this comes first, so it will be on top in Mobile. On Desktop, it's on the left. */}
                <div className="w-full lg:w-5/12 flex flex-col justify-between h-full">
                   <div>
                        <h2 className="text-4xl md:text-5xl font-thin mb-4 leading-none text-gray-900 dark:text-white">Let's work <br /><span className="font-normal text-aku-teal">together.</span></h2>
                        <p className="text-gray-600 dark:text-gray-400 leading-relaxed font-light text-base mb-8">
                            Ready to transform your digital presence? We are here to help you realize your vision.
                        </p>
                   </div>

                    <div>
                        <div className="space-y-3 mb-8">
                            <a href="mailto:hello@akustudio.com" className="flex items-center gap-3 group text-gray-900 dark:text-white">
                                <div className="w-10 h-10 rounded-full bg-white dark:bg-white/10 text-gray-900 dark:text-white flex items-center justify-center group-hover:bg-aku-teal group-hover:text-white dark:group-hover:text-black transition-colors shadow-sm">
                                    <Mail size={18} />
                                </div>
                                <span className="font-light">hello@akustudio.com</span>
                            </a>
                        </div>

                        <div className="flex gap-3">
                            {[Instagram, Linkedin, Dribbble].map((Icon, i) => (
                                <a key={i} href="#" className="w-10 h-10 rounded-full bg-white dark:bg-white/5 flex items-center justify-center text-gray-700 dark:text-white hover:bg-gray-900 dark:hover:bg-white hover:text-white dark:hover:text-black transition-all duration-300 border border-gray-200 dark:border-white/5 shadow-sm">
                                    <Icon size={18} strokeWidth={1.5} />
                                </a>
                            ))}
                        </div>
                    </div>
                </div>

                {/* Right: Compact Form */}
                <div className="w-full lg:w-7/12">
                    <motion.form 
                        initial={{ opacity: 0 }}
                        whileInView={{ opacity: 1 }}
                        viewport={{ once: true }}
                        className="space-y-3"
                    >
                        <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                            <input type="text" className="w-full bg-white dark:bg-white/5 border border-gray-300 dark:border-white/10 rounded-2xl px-6 py-4 text-sm text-gray-900 dark:text-white placeholder:text-gray-400 dark:placeholder:text-gray-500 focus:outline-none focus:border-aku-teal dark:focus:bg-black/40 transition-all font-light" placeholder="Your Name" />
                            <input type="email" className="w-full bg-white dark:bg-white/5 border border-gray-300 dark:border-white/10 rounded-2xl px-6 py-4 text-sm text-gray-900 dark:text-white placeholder:text-gray-400 dark:placeholder:text-gray-500 focus:outline-none focus:border-aku-teal dark:focus:bg-black/40 transition-all font-light" placeholder="Email Address" />
                        </div>
                        
                        <div className="relative">
                            <select className="w-full bg-white dark:bg-white/5 border border-gray-300 dark:border-white/10 rounded-2xl px-6 py-4 text-sm text-gray-900 dark:text-white focus:outline-none focus:border-aku-teal dark:focus:bg-black/40 transition-all appearance-none cursor-pointer font-light">
                            <option className="bg-white dark:bg-gray-900 text-gray-400">Select Project Type</option>
                            <option className="bg-white dark:bg-gray-900">Web Design</option>
                            <option className="bg-white dark:bg-gray-900">Branding</option>
                            <option className="bg-white dark:bg-gray-900">Development</option>
                            </select>
                            <div className="absolute right-6 top-1/2 -translate-y-1/2 pointer-events-none text-gray-500">↓</div>
                        </div>

                        <textarea rows={3} className="w-full bg-white dark:bg-white/5 border border-gray-300 dark:border-white/10 rounded-2xl px-6 py-4 text-sm text-gray-900 dark:text-white placeholder:text-gray-400 dark:placeholder:text-gray-500 focus:outline-none focus:border-aku-teal dark:focus:bg-black/40 transition-all resize-none font-light" placeholder="Tell us about your project..."></textarea>

                        <button type="button" className="w-full bg-gray-900 dark:bg-white text-white dark:text-black font-medium py-4 rounded-2xl hover:scale-[1.01] transition-all duration-300 flex items-center justify-center gap-3 text-sm mt-2 shadow-lg hover:shadow-xl hover:bg-aku-teal dark:hover:bg-aku-teal dark:hover:text-black">
                            Send Message <ArrowRight size={16} />
                        </button>
                    </motion.form>
                </div>
            </div>
        </div>

        <div className="flex flex-col md:flex-row justify-between items-center text-gray-500 dark:text-gray-600 text-xs gap-4 font-light tracking-wide max-w-5xl mx-auto">
          <p>© 2024 Aku Design Studio. Crafted with passion.</p>
          <div className="flex gap-8">
              <a href="#" className="hover:text-gray-900 dark:hover:text-white transition-colors">Privacy</a>
              <a href="#" className="hover:text-gray-900 dark:hover:text-white transition-colors">Terms</a>
          </div>
        </div>
      </div>
    </footer>
  );
};

export default Contact;
