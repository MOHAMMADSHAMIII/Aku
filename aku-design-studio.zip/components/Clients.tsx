import React from 'react';
import { motion } from 'framer-motion';
import { CLIENTS } from '../constants';
import { Hexagon, Triangle, Circle, Box, Layout, Diamond, Shield, Star } from 'lucide-react';

// Map generic logos to icons for visual variety since we don't have real SVG assets
const IconMap: Record<string, any> = {
    'Google': Circle,
    'Spotify': Hexagon,
    'Airbnb': Triangle,
    'Nike': Layout,
    'Apple': Box,
    'Uber': Diamond,
    'Netflix': Shield,
    'Tesla': Star,
};

const Clients: React.FC = () => {
  // Create infinite loop
  const marqueeClients = [...CLIENTS, ...CLIENTS, ...CLIENTS];

  return (
    <section id="clients" className="py-12 md:py-20 relative overflow-hidden border-y border-gray-200 dark:border-white/5 bg-white/50 dark:bg-black/20">
      <div className="container mx-auto px-6 mb-10 text-center">
         <p className="text-sm text-gray-500 dark:text-gray-400 uppercase tracking-widest font-medium">Trusted by Innovative Companies</p>
      </div>
      
      <div className="relative w-full overflow-hidden">
          {/* Gradient Masks */}
          <div className="absolute left-0 top-0 bottom-0 w-20 bg-gradient-to-r from-gray-50 dark:from-black to-transparent z-10 pointer-events-none"></div>
          <div className="absolute right-0 top-0 bottom-0 w-20 bg-gradient-to-l from-gray-50 dark:from-black to-transparent z-10 pointer-events-none"></div>

          <motion.div 
            className="flex items-center gap-12 md:gap-24 w-max"
            animate={{ x: ["0%", "-33.33%"] }}
            transition={{ duration: 45, ease: "linear", repeat: Infinity }}
          >
              {marqueeClients.map((client, index) => {
                  const Icon = IconMap[client.name] || Circle;
                  return (
                    <div key={`${client.name}-${index}`} className="flex items-center gap-3 opacity-40 hover:opacity-100 transition-opacity duration-300 cursor-pointer grayscale hover:grayscale-0">
                        <Icon size={32} strokeWidth={1.5} className="text-gray-900 dark:text-white" />
                        <span className="text-xl md:text-2xl font-bold text-gray-800 dark:text-white">{client.name}</span>
                    </div>
                  )
              })}
          </motion.div>
      </div>
    </section>
  );
};

export default Clients;