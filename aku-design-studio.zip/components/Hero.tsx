import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence, useMotionValue, useSpring, useTransform } from 'framer-motion';
import { PROJECTS } from '../constants';
import { ArrowRight, ChevronLeft, ChevronRight } from 'lucide-react';

const Hero: React.FC = () => {
  const [currentIndex, setCurrentIndex] = useState(0);
  const [isAutoPlaying, setIsAutoPlaying] = useState(true);
  
  // Mouse Interaction State
  const x = useMotionValue(0);
  const y = useMotionValue(0);
  const mouseXSpring = useSpring(x);
  const mouseYSpring = useSpring(y);
  
  const rotateX = useTransform(mouseYSpring, [-0.5, 0.5], ["7deg", "-7deg"]);
  const rotateY = useTransform(mouseXSpring, [-0.5, 0.5], ["-7deg", "7deg"]);
  const glareX = useTransform(mouseXSpring, [-0.5, 0.5], ["0%", "100%"]);
  const glareY = useTransform(mouseYSpring, [-0.5, 0.5], ["0%", "100%"]);

  // Use the first 4 projects for the slider
  const sliderProjects = PROJECTS.slice(0, 4);

  // Preload next image for smoother transitions
  useEffect(() => {
    const nextIdx = (currentIndex + 1) % sliderProjects.length;
    const img = new Image();
    img.src = sliderProjects[nextIdx].image;
  }, [currentIndex, sliderProjects]);

  useEffect(() => {
    if (!isAutoPlaying) return;
    const interval = setInterval(() => {
      nextSlide();
    }, 6000);
    return () => clearInterval(interval);
  }, [currentIndex, isAutoPlaying]);

  const handleMouseMove = (e: React.MouseEvent<HTMLDivElement>) => {
    const rect = e.currentTarget.getBoundingClientRect();
    const width = rect.width;
    const height = rect.height;
    
    const mouseX = e.clientX - rect.left;
    const mouseY = e.clientY - rect.top;
    
    const xPct = mouseX / width - 0.5;
    const yPct = mouseY / height - 0.5;
    
    x.set(xPct);
    y.set(yPct);
  };

  const handleMouseLeave = () => {
    x.set(0);
    y.set(0);
    setIsAutoPlaying(true);
  };

  const nextSlide = () => {
    setCurrentIndex((prev) => (prev + 1) % sliderProjects.length);
  };

  const prevSlide = () => {
    setCurrentIndex((prev) => (prev - 1 + sliderProjects.length) % sliderProjects.length);
  };

  // Staggered Container Variant
  const containerVariants = {
    hidden: { opacity: 0 },
    visible: {
      opacity: 1,
      transition: {
        staggerChildren: 0.3, // Stagger delay between children
        delayChildren: 0.2
      }
    },
    exit: { 
      opacity: 0,
      transition: { duration: 0.2 }
    }
  };

  // Item Variants
  const itemVariants = {
    hidden: { opacity: 0, y: 20 },
    visible: { 
      opacity: 1, 
      y: 0, 
      transition: { duration: 0.6, ease: "easeOut" } 
    },
    exit: { opacity: 0, y: -10 }
  };

  return (
    <section id="home" className="relative w-full min-h-screen flex flex-col justify-center overflow-hidden md:pt-24 lg:pt-32 md:pb-12">
      
      {/* Dynamic Background */}
      <div className="absolute inset-0 z-0">
        <AnimatePresence mode="wait">
            <motion.div 
                key={`bg-${currentIndex}`}
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                exit={{ opacity: 0 }}
                transition={{ duration: 1.5 }}
                className="absolute inset-0"
            >
                {/* Main Background Image - Visible on Mobile (< md) */}
                <div 
                  className="block md:hidden absolute inset-0 bg-cover bg-center transition-all duration-1000"
                  style={{ backgroundImage: `url(${sliderProjects[currentIndex].image})` }}
                />
                
                {/* Mobile Overlay: Gradient Shadow Logic (Light: White / Dark: Black) */}
                <div className="absolute inset-0 md:hidden">
                     {/* Top Gradient for Header Visibility */}
                     <div className="absolute top-0 left-0 right-0 h-48 bg-gradient-to-b from-gray-50/90 via-gray-50/50 to-transparent dark:from-black/90 dark:via-black/60 dark:to-transparent" />
                     
                     {/* Bottom Gradient for Text Legibility */}
                     <div className="absolute bottom-0 left-0 right-0 h-[60vh] bg-gradient-to-t from-gray-50 via-gray-50/90 to-transparent dark:from-black dark:via-black/90 dark:to-transparent" />
                </div>

                {/* Tablet/Desktop Background: Ambient Blur Only */}
                <div className="hidden md:block absolute inset-0 opacity-50 dark:opacity-30 blur-[120px] scale-125 saturate-[1.5] brightness-125 dark:brightness-100 bg-cover bg-center"
                     style={{ backgroundImage: `url(${sliderProjects[currentIndex].image})` }}
                />
                
                <div className="hidden md:block absolute inset-0 bg-gradient-to-b from-gray-50/90 via-gray-50/60 to-gray-50 dark:from-black/80 dark:via-black/90 dark:to-black"></div>
            </motion.div>
        </AnimatePresence>
      </div>

      <div className="container mx-auto px-6 relative z-10 h-screen md:h-auto flex flex-col md:flex-row items-center gap-10 lg:gap-20 justify-end md:justify-center pb-20 md:pb-0">
        
        {/* Left Side: Text Content */}
        {/* Added padding top/marginTop to push content down as requested */}
        <div className="w-full md:w-1/2 lg:w-5/12 flex flex-col order-2 md:order-1 mt-0 h-auto md:h-[600px] lg:h-[650px] justify-between pt-12 md:pt-20">
            
            {/* Top: Static Counter - HIDDEN ON MOBILE */}
            <div className="hidden md:flex items-center gap-3 shrink-0 mb-6 md:mb-0">
                <span className="text-aku-teal font-bold tracking-[0.2em] uppercase text-xs px-3 py-1 rounded-full bg-black/50 md:bg-aku-teal/10 border border-aku-teal/20 backdrop-blur-md">
                    Featured Work
                </span>
                <span className="h-px w-12 bg-white/50 md:bg-gray-400 md:dark:bg-white/20"></span>
                <span className="text-white md:text-gray-600 md:dark:text-white/60 font-mono text-sm font-medium">
                  0{currentIndex + 1} — 0{sliderProjects.length}
                </span>
            </div>

            {/* Middle: Dynamic Text Content */}
            {/* On mobile: Text adapts to theme because of gradient background */}
            <div className="flex-grow flex flex-col justify-end md:justify-center relative overflow-hidden min-h-[300px] md:min-h-0 pb-8">
                <AnimatePresence mode="wait">
                    <motion.div
                        key={`text-${currentIndex}`}
                        initial="hidden"
                        animate="visible"
                        exit="exit"
                        variants={containerVariants}
                        className="relative md:absolute inset-0 flex flex-col justify-end md:justify-center"
                    >
                        {/* Title */}
                        <motion.h1 variants={itemVariants} className="text-5xl md:text-5xl lg:text-8xl text-gray-900 dark:text-white mb-4 lg:mb-8 leading-[1.05] tracking-tight">
                            {sliderProjects[currentIndex].title.split('\n').map((line, i) => (
                                <span key={i} className={`block ${i === 0 ? 'font-thin text-gray-800 dark:text-gray-100' : 'font-semibold'}`}>
                                    {line}
                                </span>
                            ))}
                        </motion.h1>

                        {/* Description */}
                        <motion.p variants={itemVariants} className="text-base md:text-sm lg:text-lg text-gray-700 dark:text-gray-300 md:text-gray-600 md:dark:text-gray-300 font-light mb-6 lg:mb-8 max-w-md leading-relaxed border-l-2 border-aku-teal/50 pl-6 backdrop-blur-sm rounded-r-xl">
                            {sliderProjects[currentIndex].description}
                        </motion.p>
                        
                        {/* Tags */}
                        <motion.div variants={itemVariants} className="flex gap-2">
                            {sliderProjects[currentIndex].tags.slice(0,2).map(tag => (
                                <span key={tag} className="px-4 py-2 rounded-full border border-gray-300 dark:border-white/20 text-xs text-gray-800 dark:text-white/80 font-medium bg-white/40 dark:bg-black/20 backdrop-blur-md shadow-sm">
                                    {tag}
                                </span>
                            ))}
                        </motion.div>
                    </motion.div>
                </AnimatePresence>
            </div>

            {/* Bottom: Static Buttons Area */}
            <div className="flex flex-col gap-8 shrink-0 pt-4 lg:pt-8">
                <div className="flex items-center justify-between md:justify-start gap-6 lg:gap-8">
                    <a href="#portfolio" className="w-fit group flex items-center gap-3 px-6 lg:px-8 py-3 lg:py-4 bg-gray-900 dark:bg-white text-white dark:text-black rounded-full font-medium hover:bg-aku-teal dark:hover:bg-aku-teal hover:text-white dark:hover:text-black transition-all duration-300 shadow-xl shadow-black/10 dark:shadow-white/5 text-sm lg:text-base">
                        <span>View Case Study</span>
                        <ArrowRight className="group-hover:translate-x-1 transition-transform" size={18} />
                    </a>

                    {/* Navigation Controls */}
                    <div className="flex gap-3 lg:gap-4 z-20">
                        <button 
                            onClick={prevSlide} 
                            className="p-3 lg:p-4 rounded-full bg-white/40 dark:bg-black/20 border border-gray-300 dark:border-white/10 hover:bg-aku-teal dark:hover:bg-aku-teal hover:text-white hover:border-transparent text-gray-900 dark:text-white transition-all duration-300 backdrop-blur-md active:scale-95 shadow-sm"
                            aria-label="Previous Slide"
                        >
                            <ChevronLeft size={20} />
                        </button>
                        <button 
                            onClick={nextSlide} 
                            className="p-3 lg:p-4 rounded-full bg-white/40 dark:bg-black/20 border border-gray-300 dark:border-white/10 hover:bg-aku-teal dark:hover:bg-aku-teal hover:text-white hover:border-transparent text-gray-900 dark:text-white transition-all duration-300 backdrop-blur-md active:scale-95 shadow-sm"
                            aria-label="Next Slide"
                        >
                            <ChevronRight size={20} />
                        </button>
                    </div>
                </div>
            </div>
        </div>

        {/* Right Side: Square Image Slider (Tablet & Desktop) */}
        {/* Visible on MD screens and up */}
        <div 
          className="hidden md:flex w-full md:w-1/2 lg:w-7/12 relative items-center justify-center order-1 md:order-2 perspective-[1200px]"
          onMouseMove={handleMouseMove}
          onMouseEnter={() => setIsAutoPlaying(false)}
          onMouseLeave={handleMouseLeave}
        >
            <div className="relative w-full aspect-square max-w-[450px] lg:max-w-[600px]">
               <AnimatePresence mode='wait'>
                  <motion.div
                      key={currentIndex}
                      style={{ rotateX, rotateY }}
                      initial={{ opacity: 0, scale: 0.95, z: -50 }}
                      animate={{ opacity: 1, scale: 1, z: 0 }}
                      exit={{ opacity: 0, scale: 1.05, z: 50 }}
                      transition={{ duration: 0.7, ease: "easeInOut" }}
                      className="absolute inset-0 rounded-[2rem] lg:rounded-[3rem] overflow-hidden shadow-2xl dark:shadow-[0_30px_60px_rgba(0,0,0,0.6)] z-10 bg-gray-100 dark:bg-gray-900 ring-1 ring-white/40 dark:ring-white/10 transform-style-3d"
                  >
                      {/* Interactive Glare */}
                      <motion.div 
                        style={{ backgroundPosition: `${glareX} ${glareY}` }}
                        className="absolute inset-0 bg-gradient-to-tr from-white/20 via-transparent to-transparent z-20 pointer-events-none opacity-50" 
                      />

                      {/* Client Name Overlay (Bottom Left) */}
                       <div className="absolute bottom-0 left-0 p-8 z-30 text-left w-full bg-gradient-to-t from-black/80 to-transparent">
                            <motion.div
                                initial={{ opacity: 0, y: 10 }}
                                animate={{ opacity: 1, y: 0 }}
                                transition={{ delay: 0.3 }}
                            >
                                <p className="text-white/70 text-[10px] uppercase tracking-[0.3em] mb-2">Client</p>
                                <p className="text-white text-2xl font-normal">{sliderProjects[currentIndex].client}</p>
                            </motion.div>
                        </div>
                      
                      {/* Image with slight pan effect */}
                      <motion.img 
                          initial={{ scale: 1.1 }}
                          animate={{ scale: 1.15 }} // Subtle movement
                          transition={{ duration: 10, ease: "linear" }}
                          src={sliderProjects[currentIndex].image} 
                          alt={sliderProjects[currentIndex].title}
                          className="w-full h-full object-cover will-change-transform"
                          loading="eager"
                      />
                  </motion.div>
               </AnimatePresence>
            </div>
        </div>
      </div>
    </section>
  );
};

export default Hero;