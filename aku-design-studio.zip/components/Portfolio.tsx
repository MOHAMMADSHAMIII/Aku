
import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { PROJECTS, Project } from '../constants';
import { X, ArrowUpRight, ExternalLink, ChevronLeft, ChevronRight, Images, ArrowLeft } from 'lucide-react';

const Portfolio: React.FC = () => {
  const [selectedProject, setSelectedProject] = useState<Project | null>(null);
  const [currentImageIndex, setCurrentImageIndex] = useState(0);

  // Disable body scroll and hide navbar when modal is open
  useEffect(() => {
    if (selectedProject) {
      document.body.style.overflow = 'hidden';
      setCurrentImageIndex(0); // Reset gallery index on open
      // Dispatch custom event to hide Navbar
      window.dispatchEvent(new Event('nav-hide'));
    } else {
      document.body.style.overflow = 'unset';
      // Dispatch custom event to show Navbar
      window.dispatchEvent(new Event('nav-show'));
    }
    return () => { 
      document.body.style.overflow = 'unset';
      window.dispatchEvent(new Event('nav-show'));
    };
  }, [selectedProject]);

  const handleNextImage = (e?: React.MouseEvent) => {
    e?.stopPropagation();
    if (!selectedProject) return;
    const images = selectedProject.gallery || [selectedProject.image];
    setCurrentImageIndex((prev) => (prev + 1) % images.length);
  };

  const handlePrevImage = (e?: React.MouseEvent) => {
    e?.stopPropagation();
    if (!selectedProject) return;
    const images = selectedProject.gallery || [selectedProject.image];
    setCurrentImageIndex((prev) => (prev - 1 + images.length) % images.length);
  };

  return (
    <section id="portfolio" className="py-24 relative">
      <div className="container mx-auto px-6 relative z-10">
        <div className="flex flex-col md:flex-row md:items-end justify-between mb-20 gap-6">
          <div>
             <h2 className="text-aku-teal font-bold text-xs mb-4 tracking-[0.3em] uppercase pl-1">Selected Works</h2>
             <h3 className="text-5xl md:text-6xl font-thin text-gray-900 dark:text-white transition-colors duration-500">Our Latest <br/><span className="text-gray-400 dark:text-gray-500 font-normal">Masterpieces.</span></h3>
          </div>
          <div className="md:pb-2">
             <button className="px-8 py-3 rounded-full border border-gray-300 dark:border-white/10 bg-white dark:bg-transparent text-gray-900 dark:text-white hover:bg-gray-900 dark:hover:bg-white hover:text-white dark:hover:text-black transition-all duration-300 text-sm font-medium shadow-sm">View All Projects</button>
          </div>
        </div>

        {/* Grid Gallery */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {PROJECTS.map((project) => (
            <motion.div
              key={project.id}
              initial={{ opacity: 0, y: 40 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.6, ease: [0.22, 1, 0.36, 1] }}
              className="group relative rounded-[2.5rem] overflow-hidden cursor-pointer h-[450px] bg-gray-100 dark:bg-white/5 border border-gray-200 dark:border-white/5 transition-all shadow-sm hover:shadow-xl md:hover:scale-[1.02] active:scale-[0.98]"
              onClick={() => setSelectedProject(project)}
            >
              {/* Image */}
              <div className="w-full h-full absolute inset-0 overflow-hidden">
                <img 
                    src={project.image} 
                    alt={project.title} 
                    className="w-full h-full object-cover transition-transform duration-700 ease-out md:group-hover:scale-110"
                />
                <div className="absolute inset-0 bg-gradient-to-b from-transparent via-black/5 to-black/60 dark:to-black/80 z-10 pointer-events-none"></div>
                
                {/* Multiple Images Indicator */}
                {project.gallery && project.gallery.length > 1 && (
                    <div className="absolute top-6 left-6 z-20 bg-black/30 backdrop-blur-md px-3 py-1.5 rounded-full flex items-center gap-2 text-white border border-white/20">
                        <Images size={14} />
                        <span className="text-xs font-medium">{project.gallery.length}</span>
                    </div>
                )}
              </div>
              
              {/* Content */}
              <div className="absolute bottom-0 left-0 right-0 p-8 z-20 transform translate-y-0 md:translate-y-4 md:group-hover:translate-y-0 transition-transform duration-500">
                <div className="flex items-start justify-between mb-2">
                    <div>
                        <span className="inline-block px-3 py-1 bg-white/20 backdrop-blur-md rounded-full text-[10px] font-bold uppercase tracking-wider text-white mb-3 border border-white/10 shadow-sm">{project.category}</span>
                        <h4 className="text-white text-2xl font-normal leading-tight">{project.title}</h4>
                    </div>
                    <div className="w-10 h-10 rounded-full bg-white text-black flex items-center justify-center opacity-100 md:opacity-0 md:group-hover:opacity-100 transition-all duration-500 md:scale-50 md:group-hover:scale-100 shadow-lg">
                        <ArrowUpRight size={20} />
                    </div>
                </div>
                <p className="text-gray-200 text-sm line-clamp-2 font-light opacity-100 md:opacity-0 md:group-hover:opacity-100 transition-opacity duration-500 delay-100">{project.description}</p>
              </div>
            </motion.div>
          ))}
        </div>
      </div>

      {/* Full Screen Project Modal */}
      <AnimatePresence>
        {selectedProject && (
          <div className="fixed inset-0 z-[200] flex items-end md:items-center justify-center md:p-8">
            {/* Backdrop */}
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              onClick={() => setSelectedProject(null)}
              className="absolute inset-0 bg-black/60 backdrop-blur-2xl transition-colors duration-500"
            />

            {/* Desktop Modal Structure (md:flex) */}
            <motion.div
              initial={{ opacity: 0, scale: 0.95 }}
              animate={{ opacity: 1, scale: 1 }}
              exit={{ opacity: 0, scale: 0.95 }}
              transition={{ duration: 0.4, ease: [0.22, 1, 0.36, 1] }}
              className="hidden md:flex relative w-full max-w-6xl h-[85vh] bg-white/90 dark:bg-[#111]/90 backdrop-blur-md rounded-[3rem] overflow-hidden shadow-2xl border border-white/20 dark:border-white/10"
            >
              <button 
                onClick={() => setSelectedProject(null)}
                className="absolute top-6 right-6 z-30 w-12 h-12 flex items-center justify-center bg-white/80 dark:bg-black/50 backdrop-blur-md text-black dark:text-white rounded-full hover:scale-110 transition-all border border-gray-200 dark:border-white/10 shadow-lg"
              >
                <X size={24} />
              </button>

              {/* Image Slider Side */}
              <div className="w-1/2 h-full relative bg-gray-100 dark:bg-black group">
                <AnimatePresence mode="wait">
                    <motion.img 
                        key={currentImageIndex}
                        initial={{ opacity: 0 }}
                        animate={{ opacity: 1 }}
                        exit={{ opacity: 0 }}
                        transition={{ duration: 0.5, ease: "easeInOut" }}
                        src={(selectedProject.gallery || [selectedProject.image])[currentImageIndex]} 
                        alt={selectedProject.title} 
                        className="w-full h-full object-cover absolute inset-0"
                    />
                </AnimatePresence>
                
                {/* Navigation Arrows */}
                {(selectedProject.gallery && selectedProject.gallery.length > 1) && (
                    <>
                        <div className="absolute inset-0 flex items-center justify-between px-4 opacity-0 group-hover:opacity-100 transition-opacity duration-300 pointer-events-none">
                            <button 
                                onClick={handlePrevImage}
                                className="pointer-events-auto w-12 h-12 rounded-full bg-black/30 backdrop-blur-md text-white flex items-center justify-center hover:bg-black/60 transition-colors border border-white/10"
                            >
                                <ChevronLeft size={24} />
                            </button>
                            <button 
                                onClick={handleNextImage}
                                className="pointer-events-auto w-12 h-12 rounded-full bg-black/30 backdrop-blur-md text-white flex items-center justify-center hover:bg-black/60 transition-colors border border-white/10"
                            >
                                <ChevronRight size={24} />
                            </button>
                        </div>
                        <div className="absolute bottom-6 left-1/2 -translate-x-1/2 bg-black/40 backdrop-blur-md text-white text-xs font-medium px-4 py-2 rounded-full border border-white/10">
                            {currentImageIndex + 1} / {selectedProject.gallery.length}
                        </div>
                    </>
                )}
              </div>

              {/* Text Side */}
              <div className="w-1/2 p-16 overflow-y-auto flex flex-col h-full">
                <div className="mb-auto">
                     <span className="inline-block text-aku-teal font-bold text-xs mb-4 uppercase tracking-[0.2em]">
                        {selectedProject.category}
                    </span>
                    <h3 className="text-6xl font-thin text-gray-900 dark:text-white mb-8 leading-tight">{selectedProject.title}</h3>
                    <p className="text-gray-600 dark:text-gray-300 leading-loose font-light text-lg mb-10">{selectedProject.fullDescription}</p>
                    
                    <h5 className="text-xs font-bold text-gray-900 dark:text-white uppercase tracking-widest mb-4">Technologies</h5>
                    <div className="flex flex-wrap gap-2 mb-10">
                        {selectedProject.tags.map(tag => (
                            <span key={tag} className="text-xs text-gray-600 dark:text-gray-300 bg-gray-100 dark:bg-white/5 border border-gray-200 dark:border-white/5 px-4 py-2 rounded-full font-medium">
                            {tag}
                            </span>
                        ))}
                    </div>
                </div>
                <button className="w-full py-4 bg-gray-900 dark:bg-white text-white dark:text-black rounded-[2rem] font-medium hover:scale-[1.02] transition-all flex items-center justify-center gap-2 shadow-xl">
                    <span>View Live Project</span>
                    <ExternalLink size={18} />
                </button>
              </div>
            </motion.div>

            {/* Mobile Modal Structure (Full Screen + Clean Card Design) */}
            <motion.div
                initial={{ y: "100%" }}
                animate={{ y: 0 }}
                exit={{ y: "100%" }}
                transition={{ type: "spring", damping: 25, stiffness: 200 }}
                className="md:hidden fixed inset-0 z-[210] flex flex-col bg-white dark:bg-[#0a0a0a] overflow-hidden"
            >
                 {/* Floating Close Button */}
                 <button 
                    onClick={() => setSelectedProject(null)}
                    className="absolute top-6 right-6 z-50 w-11 h-11 flex items-center justify-center bg-black/30 backdrop-blur-lg text-white rounded-full border border-white/20 shadow-lg"
                 >
                    <X size={24} strokeWidth={2} />
                 </button>

                 {/* Scrollable Container */}
                 <div className="w-full h-full overflow-y-auto no-scrollbar flex flex-col">
                    
                    {/* Top Image Area */}
                    <div className="w-full h-[45vh] shrink-0 relative">
                        <AnimatePresence mode="wait">
                            <motion.img 
                                key={currentImageIndex}
                                initial={{ opacity: 0 }}
                                animate={{ opacity: 1 }}
                                exit={{ opacity: 0 }}
                                transition={{ duration: 0.5 }}
                                src={(selectedProject.gallery || [selectedProject.image])[currentImageIndex]} 
                                alt={selectedProject.title} 
                                className="w-full h-full object-cover"
                            />
                        </AnimatePresence>
                        
                        {/* Controls overlay */}
                        {(selectedProject.gallery && selectedProject.gallery.length > 1) && (
                            <div className="absolute bottom-12 left-0 right-0 flex justify-center gap-2 z-20">
                                {selectedProject.gallery.map((_, idx) => (
                                    <div key={idx} className={`w-1.5 h-1.5 rounded-full transition-all shadow-sm ${idx === currentImageIndex ? 'bg-white w-4' : 'bg-white/50'}`} />
                                ))}
                            </div>
                        )}

                        {/* Swipe/Tap areas for navigation */}
                        {(selectedProject.gallery && selectedProject.gallery.length > 1) && (
                           <div className="absolute inset-0 flex">
                               <div className="w-1/2 h-full" onClick={handlePrevImage}></div>
                               <div className="w-1/2 h-full" onClick={handleNextImage}></div>
                           </div>
                        )}
                    </div>

                    {/* Content Area - Rounded Card Style */}
                    <div className="relative z-10 flex-grow bg-white dark:bg-[#0a0a0a] -mt-10 rounded-t-[2.5rem] px-8 pt-10 pb-24 shadow-[0_-10px_40px_rgba(0,0,0,0.1)] dark:shadow-none min-h-[60vh]">
                        <div className="w-12 h-1.5 bg-gray-200 dark:bg-white/10 rounded-full mx-auto mb-8" />
                        
                        <span className="inline-block text-aku-teal font-bold text-xs mb-3 uppercase tracking-[0.2em]">
                            {selectedProject.category}
                        </span>
                        <h3 className="text-4xl font-thin text-gray-900 dark:text-white mb-6 leading-[1.1]">{selectedProject.title}</h3>
                        
                        <div className="prose prose-invert max-w-none mb-8 text-gray-600 dark:text-gray-300 leading-relaxed font-light text-base">
                            <p>{selectedProject.fullDescription}</p>
                        </div>

                        <div className="mb-12">
                            <h5 className="text-xs font-bold text-gray-900 dark:text-white uppercase tracking-widest mb-4">Technologies</h5>
                            <div className="flex flex-wrap gap-2">
                                {selectedProject.tags.map(tag => (
                                    <span key={tag} className="text-xs text-gray-600 dark:text-gray-300 bg-gray-100 dark:bg-white/5 border border-gray-200 dark:border-white/5 px-4 py-2 rounded-full font-medium">
                                    {tag}
                                    </span>
                                ))}
                            </div>
                        </div>

                        <button className="w-full py-4 bg-gray-900 dark:bg-white text-white dark:text-black rounded-2xl font-medium shadow-xl flex items-center justify-center gap-2 active:scale-[0.98] transition-transform">
                            <span>View Live Project</span>
                            <ExternalLink size={18} />
                        </button>
                    </div>
                 </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>
    </section>
  );
};

export default Portfolio;
