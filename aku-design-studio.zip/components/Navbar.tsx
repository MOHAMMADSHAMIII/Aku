
import React, { useState, useEffect } from 'react';
import { Sun, Moon, X } from 'lucide-react';
import { NAV_LINKS } from '../constants';
import { motion, AnimatePresence } from 'framer-motion';

const Navbar: React.FC = () => {
  const [isOpen, setIsOpen] = useState(false);
  const [isScrolled, setIsScrolled] = useState(false);
  const [isDark, setIsDark] = useState(true);
  const [isHidden, setIsHidden] = useState(false); // State to completely hide navbar

  useEffect(() => {
    // Initialize theme
    const savedTheme = localStorage.getItem('theme');
    const systemDark = window.matchMedia('(prefers-color-scheme: dark)').matches;
    
    if (savedTheme === 'dark' || (!savedTheme && systemDark)) {
      document.documentElement.classList.add('dark');
      setIsDark(true);
    } else {
      document.documentElement.classList.remove('dark');
      setIsDark(false);
    }

    const handleScroll = () => {
      const scrolled = window.scrollY > 20;
      if (isScrolled !== scrolled) {
        setIsScrolled(scrolled);
      }
    };

    // Listeners for Modal interactions
    const handleHideNav = () => setIsHidden(true);
    const handleShowNav = () => setIsHidden(false);

    window.addEventListener('scroll', handleScroll, { passive: true });
    window.addEventListener('nav-hide', handleHideNav);
    window.addEventListener('nav-show', handleShowNav);

    return () => {
      window.removeEventListener('scroll', handleScroll);
      window.removeEventListener('nav-hide', handleHideNav);
      window.removeEventListener('nav-show', handleShowNav);
    };
  }, [isScrolled]);

  useEffect(() => {
    if (isOpen) {
      document.body.style.overflow = 'hidden';
    } else {
      document.body.style.overflow = 'unset';
    }
  }, [isOpen]);

  const toggleTheme = () => {
    if (isDark) {
      document.documentElement.classList.remove('dark');
      localStorage.setItem('theme', 'light');
      setIsDark(false);
    } else {
      document.documentElement.classList.add('dark');
      localStorage.setItem('theme', 'dark');
      setIsDark(true);
    }
  };

  const hamburgerLine = "h-[2px] w-6 rounded-full bg-current transition-all duration-300 ease-out";

  return (
    <div className={`fixed top-0 left-0 right-0 z-50 flex justify-center pointer-events-none pt-0 transition-transform duration-700 ease-in-out ${isHidden ? '-translate-y-[150%]' : 'translate-y-0'}`}>
      <motion.nav 
        initial={{ y: -100 }}
        animate={{ y: 0 }}
        className={`pointer-events-auto flex justify-between items-center transition-all duration-500 cubic-bezier(0.32, 0.72, 0, 1) ${
          isScrolled 
            ? 'w-[94%] md:w-[90%] lg:w-[880px] mt-4 md:mt-6 py-3 px-5 md:py-4 md:px-8 rounded-full bg-white/70 dark:bg-[#121212]/70 backdrop-blur-xl border border-white/40 dark:border-white/5 shadow-[0_8px_40px_rgba(0,0,0,0.08)] dark:shadow-[0_20px_40px_rgba(0,0,0,0.6)]' 
            : 'w-full py-6 px-6 lg:px-10 bg-transparent border-transparent'
        }`}
      >
        {/* Logo - Left aligned on all screens */}
        <div className={`flex items-center transition-all duration-500 shrink-0 z-50 ${isScrolled ? 'gap-2' : 'gap-3'}`}>
            <div className={`transition-all duration-500 ${isScrolled ? 'w-9 h-9' : 'w-9 h-9 lg:w-10 lg:h-10'} bg-gradient-to-br from-aku-teal to-blue-600 rounded-full flex items-center justify-center shadow-lg shadow-aku-teal/20 shrink-0`}>
                <span className="text-white font-bold text-sm lg:text-lg">A</span>
            </div>
            {/* Desktop Text (Next to logo) - Visible only on XL screens to prevent overlap */}
            <span className={`hidden xl:block font-light tracking-wide transition-all duration-500 ${isScrolled ? 'text-base text-gray-900 dark:text-white' : 'text-lg text-gray-800 dark:text-white'}`}>
               Aku
            </span>
        </div>

        {/* Mobile/Tablet Center Text "AKU" - Visible below XL */}
        <div className="xl:hidden absolute left-1/2 top-1/2 -translate-x-1/2 -translate-y-1/2 z-10">
            <span className={`font-bold tracking-widest uppercase transition-all duration-500 ${isScrolled ? 'text-base text-gray-900 dark:text-white' : 'text-xl text-gray-900 dark:text-white'}`}>
                Aku
            </span>
        </div>

        {/* Desktop Menu - Hidden on Tablet/Mobile (Visible on XL+) */}
        <div className="hidden xl:flex items-center absolute left-1/2 -translate-x-1/2">
          <div className={`flex items-center transition-all duration-500 ${!isScrolled ? 'bg-white/10 dark:bg-black/20 backdrop-blur-sm border border-white/20 dark:border-white/5 rounded-full px-2 py-1' : ''}`}>
            {NAV_LINKS.map((link) => (
              <a
                key={link.name}
                href={link.href}
                className={`rounded-full transition-all duration-300 ${
                  !isScrolled 
                    ? 'px-4 py-2 text-sm font-light text-gray-800 dark:text-white/90 hover:bg-white/50 dark:hover:bg-white/10 hover:text-black dark:hover:text-white' 
                    : 'px-4 py-2 text-sm font-medium text-gray-600 dark:text-white/70 hover:text-black dark:hover:text-white hover:bg-gray-100 dark:hover:bg-white/10'
                }`}
              >
                {link.name}
              </a>
            ))}
          </div>
        </div>

        {/* Desktop Actions (Theme + CTA) - Hidden on Tablet/Mobile (Visible on XL+) */}
        <div className={`hidden xl:flex items-center shrink-0 z-20 ${isScrolled ? 'gap-3' : 'gap-3'}`}>
            <button 
              onClick={toggleTheme}
              className={`rounded-full flex items-center justify-center transition-all duration-300 active:scale-95 ${
                isScrolled 
                  ? 'w-10 h-10 text-gray-700 dark:text-white bg-gray-100 dark:bg-white/10 hover:bg-gray-200 dark:hover:bg-white/20'
                  : 'w-9 h-9 text-gray-800 dark:text-white bg-white/20 dark:bg-white/10 hover:bg-white/40 dark:hover:bg-white/20'
              }`}
              aria-label="Toggle Theme"
            >
              {isDark ? <Sun size={18} /> : <Moon size={18} />}
            </button>

            <a href="#contact" className={`bg-gray-900 dark:bg-white text-white dark:text-black font-medium rounded-full hover:scale-105 hover:bg-aku-teal dark:hover:bg-aku-teal hover:text-white dark:hover:text-black transition-all duration-300 shadow-lg shadow-gray-900/10 dark:shadow-white/10 whitespace-nowrap ${isScrolled ? 'px-5 py-2.5 text-sm' : 'px-6 py-2.5 text-sm'}`}>
                Let's Talk
            </a>
        </div>

        {/* Mobile/Tablet Menu Button (Right aligned) - Visible below XL */}
        <div className="flex items-center gap-3 xl:hidden ml-auto z-50">
          <button 
            className={`w-11 h-11 flex flex-col items-center justify-center gap-[5px] rounded-full transition-colors active:scale-95 ${
                isScrolled || isOpen
                ? 'text-gray-900 dark:text-white bg-gray-100 dark:bg-white/10' 
                : 'text-gray-900 dark:text-white bg-white/30 dark:bg-white/10 backdrop-blur-md'
            }`}
            onClick={() => setIsOpen(!isOpen)}
            aria-label="Toggle Menu"
          >
             {/* Improved Animated Hamburger Icon */}
             <div className={`${hamburgerLine} ${isOpen ? "rotate-45 translate-y-[7px]" : ""}`} />
             <div className={`${hamburgerLine} ${isOpen ? "opacity-0 translate-x-2" : ""}`} />
             <div className={`${hamburgerLine} ${isOpen ? "-rotate-45 -translate-y-[7px]" : ""}`} />
          </button>
        </div>
      </motion.nav>

      {/* Full Screen Mobile Menu Overlay */}
      <AnimatePresence>
        {isOpen && (
          <motion.div 
            initial={{ opacity: 0, clipPath: "circle(0% at 100% 0%)" }}
            animate={{ opacity: 1, clipPath: "circle(150% at 100% 0%)" }}
            exit={{ opacity: 0, clipPath: "circle(0% at 100% 0%)" }}
            transition={{ duration: 0.5, ease: [0.76, 0, 0.24, 1] }}
            className="fixed inset-0 z-[45] bg-gray-50/95 dark:bg-black/95 backdrop-blur-xl pointer-events-auto flex flex-col justify-center items-center h-[100dvh]"
          >
             {/* Background Accents */}
             <div className="absolute inset-0 overflow-hidden pointer-events-none">
                <div className="absolute top-[-10%] right-[-10%] w-96 h-96 bg-aku-teal/10 rounded-full blur-3xl"></div>
                <div className="absolute bottom-[-10%] left-[-10%] w-80 h-80 bg-blue-500/10 rounded-full blur-3xl"></div>
             </div>

             <div className="w-full max-w-md px-6 relative z-10 flex flex-col items-center">
                <div className="flex flex-col space-y-6 w-full items-center">
                  {NAV_LINKS.map((link, index) => (
                    <motion.a
                      key={link.name}
                      href={link.href}
                      initial={{ opacity: 0, y: 20 }}
                      animate={{ opacity: 1, y: 0 }}
                      transition={{ delay: 0.2 + (index * 0.05), duration: 0.5 }}
                      className="text-4xl md:text-5xl font-light text-gray-800 dark:text-white hover:text-aku-teal dark:hover:text-aku-teal transition-colors tracking-tight"
                      onClick={() => setIsOpen(false)}
                    >
                      {link.name}
                    </motion.a>
                  ))}
                </div>
                
                <motion.div 
                    initial={{ opacity: 0, y: 20 }}
                    animate={{ opacity: 1, y: 0 }}
                    transition={{ delay: 0.5, duration: 0.5 }}
                    className="mt-16 flex flex-col gap-6 w-full items-center"
                >
                    <button 
                        onClick={() => { toggleTheme(); }}
                        className="flex items-center gap-3 px-8 py-4 rounded-full bg-gray-200 dark:bg-white/10 text-gray-800 dark:text-white hover:bg-gray-300 dark:hover:bg-white/20 transition-colors"
                    >
                        {isDark ? <Sun size={20} /> : <Moon size={20} />}
                        <span className="text-base font-medium">{isDark ? 'Switch to Light' : 'Switch to Dark'}</span>
                    </button>

                    <a href="#contact" onClick={() => setIsOpen(false)} className="px-10 py-4 bg-gray-900 dark:bg-white text-white dark:text-black font-medium rounded-full hover:bg-aku-teal dark:hover:bg-aku-teal hover:text-white dark:hover:text-black transition-all shadow-lg">
                        Start a Project
                    </a>
                </motion.div>
             </div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
};

export default Navbar;
