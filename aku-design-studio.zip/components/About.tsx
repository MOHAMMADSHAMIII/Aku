
import React, { useState } from 'react';
import { motion, AnimatePresence, useMotionValue, useTransform } from 'framer-motion';
import { ABOUT_CONTENT } from '../constants';
import { Layers, PenTool, Type, MousePointer2, Box, LayoutGrid, ArrowRight as ArrowIcon, Palette, Smartphone, Package, Monitor } from 'lucide-react';

const About: React.FC = () => {
  const [activeSkillIndex, setActiveSkillIndex] = useState(0);
  
  // Mouse Interaction for visuals
  const x = useMotionValue(0);
  const y = useMotionValue(0);
  
  // Move useTransform to top level
  const rotateX = useTransform(y, [0, 300], [10, -10]);
  const rotateY = useTransform(x, [0, 300], [-10, 10]);
  const moveX = useTransform(x, [0, 500], [-20, 20]);
  const moveY = useTransform(y, [0, 500], [-20, 20]);

  const handleMouseMove = (e: React.MouseEvent) => {
    const rect = e.currentTarget.getBoundingClientRect();
    x.set(e.clientX - rect.left);
    y.set(e.clientY - rect.top);
  };

  // Custom renderers for lightweight, interactive 2D visuals
  const renderVisual = (index: number) => {
    switch (index) {
        case 0: // UI/UX Design
            return (
                <motion.div 
                    key="ui-ux"
                    initial={{ opacity: 0, scale: 0.8 }}
                    animate={{ opacity: 1, scale: 1 }}
                    exit={{ opacity: 0, scale: 0.8 }}
                    transition={{ duration: 0.4 }}
                    className="relative w-full h-full flex justify-center items-center"
                >
                    <motion.div 
                        style={{ x: moveX, y: moveY }}
                        className="relative z-10"
                    >
                        <div className="w-32 h-32 bg-gradient-to-br from-aku-teal to-blue-600 rounded-3xl shadow-2xl shadow-aku-teal/30 flex items-center justify-center">
                             <Smartphone size={48} className="text-white" strokeWidth={1.5} />
                        </div>
                    </motion.div>
                    
                    {/* Floating Elements */}
                    <motion.div 
                        animate={{ y: [-10, 10, -10] }}
                        transition={{ duration: 4, repeat: Infinity, ease: "easeInOut" }}
                        className="absolute top-1/3 left-1/4 bg-white dark:bg-gray-800 p-3 rounded-2xl shadow-lg"
                    >
                        <MousePointer2 size={20} className="text-aku-teal" />
                    </motion.div>

                     <motion.div 
                        animate={{ y: [10, -10, 10] }}
                        transition={{ duration: 5, repeat: Infinity, ease: "easeInOut", delay: 1 }}
                        className="absolute bottom-1/3 right-1/4 bg-white dark:bg-gray-800 p-3 rounded-2xl shadow-lg"
                    >
                        <LayoutGrid size={20} className="text-gray-900 dark:text-white" />
                    </motion.div>
                </motion.div>
            );

        case 1: // Brand Identity
            return (
                <motion.div 
                    key="branding"
                    initial={{ opacity: 0 }}
                    animate={{ opacity: 1 }}
                    exit={{ opacity: 0 }}
                    className="relative w-full h-full flex flex-col justify-center items-center"
                >
                    <motion.div 
                         style={{ rotateX, rotateY }}
                         className="w-40 h-40 bg-gray-900 dark:bg-white rounded-full flex items-center justify-center shadow-2xl perspective-500"
                    >
                        {/* Font Serif Removed */}
                        <span className="text-6xl font-sans text-white dark:text-black font-bold">Aa</span>
                    </motion.div>
                    
                    {/* Orbiting Palette */}
                    <motion.div 
                        animate={{ rotate: 360 }}
                        transition={{ duration: 20, repeat: Infinity, ease: "linear" }}
                        className="absolute w-64 h-64 rounded-full border border-dashed border-gray-300 dark:border-white/10"
                    >
                         <div className="absolute top-0 left-1/2 -translate-x-1/2 -translate-y-1/2 w-8 h-8 bg-aku-teal rounded-full shadow-lg"></div>
                         <div className="absolute bottom-0 left-1/2 -translate-x-1/2 translate-y-1/2 w-8 h-8 bg-blue-600 rounded-full shadow-lg"></div>
                    </motion.div>
                </motion.div>
            );

        case 2: // Graphic Design
            return (
                <motion.div 
                    key="graphics"
                    initial={{ opacity: 0 }}
                    animate={{ opacity: 1 }}
                    exit={{ opacity: 0 }}
                    className="relative w-full h-full flex justify-center items-center"
                >
                     <motion.div
                        whileHover={{ scale: 1.1, rotate: 10 }}
                        className="relative z-10"
                     >
                        <PenTool size={80} className="text-gray-900 dark:text-white" strokeWidth={1} />
                     </motion.div>

                     {/* Morphing Blobs behind */}
                     <motion.div 
                        className="absolute w-48 h-48 bg-aku-teal/20 rounded-full blur-2xl"
                        animate={{ scale: [1, 1.2, 1], opacity: [0.5, 0.8, 0.5] }}
                        transition={{ duration: 3, repeat: Infinity }}
                     />
                </motion.div>
            );

        case 3: // Packaging Design
             return (
                <motion.div 
                    key="packaging"
                    initial={{ opacity: 0 }}
                    animate={{ opacity: 1 }}
                    exit={{ opacity: 0 }}
                    className="relative w-full h-full flex flex-col justify-center items-center"
                >
                    <motion.div 
                        style={{ rotateX, rotateY }}
                        className="w-32 h-40 border-2 border-gray-900 dark:border-white rounded-xl flex items-center justify-center relative bg-white/50 dark:bg-white/5 backdrop-blur-sm"
                    >
                        <Package size={40} className="text-gray-900 dark:text-white" />
                        
                        {/* Lid Animation */}
                         <motion.div 
                            className="absolute -top-8 left-0 right-0 h-8 border-2 border-b-0 border-gray-900 dark:border-white rounded-t-xl origin-bottom"
                            animate={{ rotateX: [0, -45, 0] }}
                            transition={{ duration: 3, repeat: Infinity, ease: "easeInOut" }}
                        />
                    </motion.div>
                </motion.div>
             );
        
        default:
            return null;
    }
  };

  return (
    <section id="about" className="py-20 md:py-32 relative">
      <div className="container mx-auto px-6 relative z-10">
        <div className="glass-panel rounded-[3rem] p-6 md:p-16 flex flex-col lg:flex-row gap-12 items-stretch transition-all duration-500 min-h-[600px]">
          
          {/* Left Side: Interactive List */}
          <div className="w-full lg:w-5/12 flex flex-col justify-center order-2 lg:order-1">
            <motion.div
              initial={{ opacity: 0, y: 30 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.8, ease: "easeOut" }}
            >
              <div className="flex items-center gap-2 mb-8">
                <span className="w-2 h-2 bg-aku-teal rounded-full animate-pulse"></span>
                <span className="text-aku-teal font-bold tracking-[0.2em] uppercase text-xs">Services</span>
              </div>
              
              <h3 className="text-4xl md:text-5xl font-thin text-gray-900 dark:text-white mb-10 leading-tight">
                Bridging dreams & <br/>
                <span className="text-gray-400 dark:text-gray-500 font-normal">digital reality.</span>
              </h3>
              
              <div className="space-y-3">
                {ABOUT_CONTENT.skills.map((skill, index) => (
                    <motion.div 
                        key={index}
                        onMouseEnter={() => setActiveSkillIndex(index)}
                        className={`relative p-6 rounded-2xl cursor-pointer transition-all duration-300 border group ${
                            activeSkillIndex === index 
                            ? 'bg-white dark:bg-white/10 border-aku-teal/30 shadow-xl shadow-aku-teal/5 scale-[1.02]' 
                            : 'bg-transparent border-transparent hover:bg-gray-50 dark:hover:bg-white/5'
                        }`}
                    >
                        <div className="flex items-center justify-between relative z-10">
                            <div className="flex items-center gap-5">
                                {/* Enhanced Icon Container */}
                                <div className={`w-12 h-12 rounded-xl flex items-center justify-center transition-all duration-500 ${
                                    activeSkillIndex === index 
                                    ? 'bg-gradient-to-br from-aku-teal to-blue-500 text-white shadow-lg shadow-aku-teal/30' 
                                    : 'bg-gray-100 dark:bg-white/5 text-gray-400 dark:text-gray-500 group-hover:bg-white group-hover:shadow-md dark:group-hover:bg-white/10'
                                }`}>
                                    {index === 0 && <Smartphone size={22} strokeWidth={1.5} />}
                                    {index === 1 && <Type size={22} strokeWidth={1.5} />}
                                    {index === 2 && <Palette size={22} strokeWidth={1.5} />}
                                    {index === 3 && <Package size={22} strokeWidth={1.5} />}
                                </div>

                                <span className={`text-xl font-medium transition-colors ${activeSkillIndex === index ? 'text-gray-900 dark:text-white' : 'text-gray-500 dark:text-gray-400 group-hover:text-gray-800 dark:group-hover:text-gray-200'}`}>
                                    {skill}
                                </span>
                            </div>
                            
                            <motion.div 
                                animate={{ x: activeSkillIndex === index ? 0 : -10, opacity: activeSkillIndex === index ? 1 : 0 }}
                                className="text-aku-teal"
                            >
                                <ArrowIcon />
                            </motion.div>
                        </div>
                    </motion.div>
                ))}
              </div>

            </motion.div>
          </div>

          {/* Right Side: Dynamic 2D Visualization Area - HIDDEN ON MOBILE */}
          <div 
            onMouseMove={handleMouseMove}
            className="hidden lg:flex w-full lg:w-7/12 relative items-center justify-center order-1 lg:order-2 overflow-hidden rounded-[2.5rem] bg-gradient-to-br from-gray-50 via-gray-100 to-gray-50 dark:from-white/5 dark:via-black/20 dark:to-white/5 border border-white/20 dark:border-white/5 h-[300px] lg:h-auto mt-6 lg:mt-0 shadow-inner"
          >
             <div className="absolute inset-0 bg-[url('https://grainy-gradients.vercel.app/noise.svg')] opacity-10 mix-blend-overlay"></div>
             <AnimatePresence mode='wait'>
                {renderVisual(activeSkillIndex)}
             </AnimatePresence>
          </div>
        </div>
      </div>
    </section>
  );
};

// Helper Icon for arrow
const ArrowRight = () => (
    <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M5 12h14"/><path d="m12 5 7 7-7 7"/></svg>
)

export default About;
